# FacetWP Manipulator
Manipulate FacetWP easily by applying custom code to FacetWP Hooks.
